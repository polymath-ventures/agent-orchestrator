# Redesign the sidebar quota widget: meter-based hierarchy + severity color

## Summary

The sidebar-footer quota widget (`QuotaPanel`) has no visual hierarchy. Each usage
window renders the window name, the `% used`, and the dated reset stamp as flat
mono text of near-equal weight, so the **reset timestamp visually dominates the
number you actually care about**, wraps to two lines in the narrow rail, and there
is nothing to scan at a glance.

Redesign each window as a **meter**: the `% used` + a progress bar are the hero,
the reset drops to one quiet secondary line, and the bar/number take a **severity
color** so "nearly out" is glanceable.

See `resources/` for a working HTML mockup (dark + light, all states) and
before/after screenshots.

## Scope

- File: `frontend/src/renderer/components/QuotaPanel.tsx`
- Tests: `frontend/src/renderer/components/QuotaPanel.test.tsx`
- Tokens: `frontend/src/styles/tokens.css` (add one track token; reuse existing status colors)
- No API/daemon changes. Data model is unchanged — this is presentation only.

## Data model (unchanged)

Per `QuotaSnapshot`: `windowName` (e.g. `"week (all models)"`, `"session"`,
`"primary"`), `used` (number, **percent 0–100**), `windowEnd` (ISO reset instant).
`pickWindows()` still selects a headline + optional secondary window per harness;
`formatReset()` still produces the dated stamp; `HarnessChip` still shows the
`updated {age}` label and owns the per-harness card + `Probe now` action.

## What to build

Replace `WindowLine` (and its consumption in `UsageLines`) with a **meter row**:

```
week · all models                    47%      ← name (mono, muted, truncates) + % (bold, severity color)
▓▓▓▓▓▓▓░░░░░░░░░░░░░░░                          ← bar: 6px tall, radius-full, track + fill
🕐 resets Mon 27 Jul · 14:00                    ← reset: micro mono, passive, clock icon; NOT the focus
```

### Meter

- Track: full-width, `height: 6px`, `rounded-full`, background = new
  `--color-quota-track` (dark `rgb(255 255 255 / 0.09)`, light `rgb(0 0 0 / 0.08)`).
- Fill: `width: {clamp(used, 0, 100)}%`, `rounded-full`, `transition-[width]`.
- Give a 0% window a hairline of fill (min-width ~2px) so the row still reads as a meter.

### Severity (drives fill color, `%` color, and the reset line when critical)

| used | fill / number | notes |
| ---- | ------------- | ----- |
| `< 75` | `--color-accent` | number in `--color-foreground` (or `--color-text-passive` when `used === 0`) |
| `75–89` | `--color-warning` (amber) | number in amber |
| `>= 90` | `--color-danger` (red) | number + reset line in red; prefix reset with a `TriangleAlert` icon and an `N% left` clause |

This generalizes the current "warn once ≤10% remains" (`used >= 90`) rule into a
three-stop scale; keep 90 as the hard warning threshold.

### Reset line

- `formatReset()` output, restyled to `text-micro` (10px) mono, `--color-text-passive`,
  prefixed with a `Clock` lucide icon (~10px). One line; it must **not** compete with the number.
- Keep the full dated stamp (weekday + month + day + time [+ TZ]) — the original
  "resets 2:00 PM with no date" ambiguity must stay fixed. It's fine to render TZ
  smaller/omit on overflow, but never drop the date.

### Card / header / states (keep)

- Panel chrome unchanged: chevron collapse, `Gauge` icon, `QUOTA` eyebrow
  (`text-caption` mono uppercase), `RefreshCw` (spins while `refreshing`).
- `HarnessChip`: card = `rounded-lg border border-border bg-background`, header =
  harness `label` (`text-sm`/12px semibold) + `updated {age}` (`text-micro` passive).
  (Bump the card radius from `rounded` to `rounded-lg` to match other rows.)
- Preserve every non-`ok`/non-data branch of `ChipBody` exactly as inline actions
  (never tooltip-only): `not_probed` → "not probed yet" + `Probe now`; `failed` →
  amber reason + retry; `no_source`; empty `ok` → "no usage recorded yet" + probe.
- Collapsed state and the `probe failed — retry` alert row unchanged.

## Acceptance criteria

- [ ] Each usage window renders as name + `% used` + a 6px progress bar + a quiet reset line.
- [ ] The `% used` number is the most prominent element in a window row; the reset is visibly secondary (smaller, passive).
- [ ] Fill + number color follow the severity table (`<75` accent, `75–89` amber, `≥90` red); `used === 0` reads as an empty/near-empty neutral bar.
- [ ] `≥ 90%` shows the red state with an `N% left` clause and alert glyph on the reset line.
- [ ] Reset always shows the full **dated** stamp; no bare clock time regression.
- [ ] Headline vs secondary window selection (`pickWindows`) and all inline probe/error/no-source states are unchanged in behavior.
- [ ] Narrow-rail safe: window name truncates, `%` never clips, reset stays on one line at 216px inner width.
- [ ] `--color-quota-track` added for dark + light in `tokens.css`.
- [ ] `QuotaPanel.test.tsx` updated: assert the bar fill width/aria for a known `used`, severity class at boundaries (74/75/89/90), and that the dated reset text still renders.
- [ ] Meets a11y: bar has `role="progressbar"` + `aria-valuenow/min/max` and an accessible name (harness + window); color is not the only severity signal (number + `% left` text carry it too).

## Notes

- Use existing tokens only (`--color-accent`, `--color-warning`, `--color-danger`,
  `--color-foreground`, `--color-text-muted`, `--color-text-passive`, `--radius-full`,
  `--radius-lg`) plus the one new track token. Do not introduce new hues.
- lucide icons already in use: `Gauge`, `RefreshCw`, `Loader2`, `ChevronDown/Right`.
  Add `Clock` and `TriangleAlert`.
- Blue is AO's "live edge" accent; a meter fill is functional (not decorative) use, consistent with the design system.

## Resources (`resources/`)

- `quota-widget-redesign.html` — self-contained interactive mockup: before/after, severity states, non-data states, collapsed header, dark + light. Open in a browser.
- `before.png` — current widget.
- `after-dark.png`, `after-states-light.png` — target design.
